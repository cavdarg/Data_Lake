#!/bin/bash

# Chemin des exécutables Kafka
KAFKA_HOME="/mnt/c/Users/gucav/kafka_2.13-3.8.0"  # Remplace par le chemin réel vers Kafka
PROJECT_DIR="/home/gcavdar/Projet_data_lakes"
RAW_ZONE_DIR="$PROJECT_DIR/Raw/campagnes"  

# Fonction pour afficher un message
function echo_step {
    echo -e "\n--- $1 ---\n"
}

# Étape 1 : Démarrer Zookeeper et Kafka
echo_step "Démarrage de Zookeeper et Kafka"
"$KAFKA_HOME/bin/zookeeper-server-start.sh" -daemon "$KAFKA_HOME/config/zookeeper.properties"
"$KAFKA_HOME/bin/kafka-server-start.sh" -daemon "$KAFKA_HOME/config/server.properties"

# Pause pour laisser Zookeeper et Kafka démarrer
sleep 10

# Étape 2 : Créer le topic Kafka
echo_step "Création du topic Kafka 'ad_events'"
"$KAFKA_HOME/bin/kafka-topics.sh" --create --topic ad_events --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1

# Étape 3 : Configurer l'environnement virtuel
echo_step "Configuration de l'environnement virtuel Python"
python3 -m venv /home/gcavdar/myenv_new
source /home/gcavdar/myenv_new/bin/activate
pip install kafka-python

# Étape 4 : Créer les scripts Producer et Consumer
echo_step "Création du script producer.py"
cat <<EOL > "$PROJECT_DIR/producer.py"
import json
import time
from kafka import KafkaProducer

producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda x: json.dumps(x).encode('utf-8')
)

messages = [
    {"ad_id": "ad_1", "user_id": "user_1", "click": True, "impression": True, "timestamp": "2024-11-17T15:00:00", "ad_platform": "Facebook", "product_category": "Chaussures"},
    {"ad_id": "ad_2", "user_id": "user_2", "click": False, "impression": True, "timestamp": "2024-11-17T15:01:00", "ad_platform": "Google Ads", "product_category": "Vêtements"}
]

for message in messages:
    producer.send('ad_events', value=message)
    print(f"Message envoyé : {message}")
    time.sleep(1)
EOL

echo_step "Création du script consumer.py"
cat <<EOL > "$PROJECT_DIR/consumer.py"
import json
import os
from kafka import KafkaConsumer
from datetime import datetime
import pytz

consumer = KafkaConsumer(
    'ad_events',
    bootstrap_servers=['localhost:9092'],
    auto_offset_reset='earliest',
    enable_auto_commit=True,
    value_deserializer=lambda x: json.loads(x.decode('utf-8'))
)

raw_zone_path = "$RAW_ZONE_DIR"
os.makedirs(raw_zone_path, exist_ok=True)
events = []
local_timezone = pytz.timezone('Europe/Paris')

for message in consumer:
    event = message.value
    print(f"Reçu : {event}")
    events.append(event)

    current_time = datetime.now(local_timezone)
    print(f"Test d'heure : {current_time.hour}:{current_time.minute}")

    if current_time.minute % 1 == 0:
        try:
            file_name = f"ad_events_{current_time.strftime('%Y-%m-%d')}.json"
            file_path = os.path.join(raw_zone_path, file_name)
            with open(file_path, 'w') as f:
                json.dump(events, f, indent=2)
            print(f"Données sauvegardées dans : {file_path}")
            events = []
        except Exception as e:
            print(f"Erreur lors de l'écriture dans le fichier : {str(e)}")
EOL

# Étape 5 : Configurer la tâche cron
echo_step "Configuration de la tâche cron pour l'ingestion des données"
cat <<EOL > "$PROJECT_DIR/run_consumer.sh"
#!/bin/bash
source $PROJECT_DIR/myenv_new/bin/activate
python $PROJECT_DIR/consumer.py
deactivate
EOL

chmod +x "$PROJECT_DIR/run_consumer.sh"

(crontab -l 2>/dev/null; echo "* * * * * $PROJECT_DIR/run_consumer.sh >> $PROJECT_DIR/cron_log.log 2>&1") | crontab -

# Étape 6 : Lancer le producer
echo_step "Lancement du producer"
python "$PROJECT_DIR/producer.py"

echo_step "Configuration terminée. Les données seront ingérées chaque minute."
