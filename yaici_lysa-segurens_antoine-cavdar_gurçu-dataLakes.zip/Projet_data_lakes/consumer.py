from kafka import KafkaConsumer
import json

# Configuration du Consommateur Kafka
consumer = KafkaConsumer(
    'ad_events',  # Nom du topic Kafka
    bootstrap_servers=['localhost:9092'],  # Adresse de Kafka
    auto_offset_reset='earliest',  # Commence à lire les messages depuis le début si aucun offset n'est trouvé
    enable_auto_commit=True,  # Confirmer automatiquement la réception des messages
    value_deserializer=lambda x: json.loads(x.decode('utf-8'))  # Décoder les messages JSON
)

# Lire les messages du topic
print("Consommateur démarré. En attente des messages...")
for message in consumer:
    event = message.value  # Récupérer le message du topic
    print(f"Reçu : {event}")  # Afficher le message

