import json
import os
from kafka import KafkaConsumer
from datetime import datetime
import pytz  # Pour gérer les fuseaux horaires

# Configuration du consommateur Kafka
consumer = KafkaConsumer(
    'ad_events',  # Nom du topic
    bootstrap_servers=['localhost:9092'],
    auto_offset_reset='earliest',  # Lire depuis le début
    enable_auto_commit=True,  # Confirmer automatiquement la réception des messages
    value_deserializer=lambda x: json.loads(x.decode('utf-8'))  # Décoder les messages JSON
)

# Dossier de la Raw Zone
raw_zone_path = "/home/gcavdar/Projet_data_lakes/Raw/campagnes"  # Chemin sous WSL
os.makedirs(raw_zone_path, exist_ok=True)

# Liste pour collecter les événements
events = []

# Récupérer l'heure locale correcte (par exemple, Paris)
local_timezone = pytz.timezone('Europe/Paris')  # Fuseau horaire Paris

# Collecte des messages Kafka
for message in consumer:
    event = message.value
    print(f"Reçu : {event}")
    events.append(event)  # Ajouter les événements dans la liste

    # Récupérer l'heure actuelle en UTC et la convertir en heure locale
    current_time = datetime.now(local_timezone)  # Heure locale
    print(f"Test d'heure : {current_time.hour}:{current_time.minute}")

    # Sauvegarder chaque minute
    if current_time.second == 0:  # On s'assure que l'écriture se fait au début de chaque minute
        try:
            # Écriture dans la Raw Zone
            file_name = f"ad_events_{current_time.strftime('%Y-%m-%d_%H-%M')}.json"
            file_path = os.path.join(raw_zone_path, file_name)
            with open(file_path, 'w') as f:
                json.dump(events, f, indent=2)  # Sauvegarder tous les événements
            print(f"Données sauvegardées dans : {file_path}")
            events = []  # Réinitialiser les événements après sauvegarde
        except Exception as e:
            print(f"Erreur lors de l'écriture dans le fichier : {str(e)}")
