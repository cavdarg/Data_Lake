from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum, count, round, when, lit
import os
import glob
import shutil

# 1/ Initialiser SparkSession
spark = SparkSession.builder \
    .appName("E-Commerce Data Pipeline") \
    .getOrCreate()

# 2/ Définir les chemins pour les zones raw et staging
raw_path = "/home/gcavdar/Projet_data_lakes/Raw/transactions"
staging_path = "/home/gcavdar/Projet_data_lakes/Staging/transactions"

# 3/ Charger les fichiers depuis la zone raw
clients_df = spark.read.option("delimiter", ",").option("header", "true").csv(f"{raw_path}/clients.csv")
commandes_df = spark.read.option("delimiter", ",").option("header", "true").csv(f"{raw_path}/commandes.csv")
details_commande_df = spark.read.option("delimiter", ",").option("header", "true").csv(f"{raw_path}/details_commande.csv")
produits_df = spark.read.option("delimiter", ",").option("header", "true").csv(f"{raw_path}/produits.csv")

# 4/ Suppression des doublons
clients_df = clients_df.dropDuplicates()
commandes_df = commandes_df.dropDuplicates()
details_commande_df = details_commande_df.dropDuplicates()
produits_df = produits_df.dropDuplicates()

print(f"Nombre initial de lignes dans details_commande_df : {details_commande_df.count()}")

# 5/ Gestion des valeurs nulles
def handle_nulls(df, column, default_value):
    return df.withColumn(column, when(col(column).isNull(), lit(default_value)).otherwise(col(column)))

clients_df = handle_nulls(clients_df, "mail", "unknown@mail.com")
clients_df = handle_nulls(clients_df, "telephone", "unknown")
commandes_df = handle_nulls(commandes_df, "statut", "En attente")

# 6/ Vérification des colonnes ID manquantes
missing_ids_clients = clients_df.filter(col("client_id").isNull()).count()
missing_ids_commandes = commandes_df.filter(col("commande_id").isNull()).count()
missing_ids_details = details_commande_df.filter(col("details_id").isNull()).count()
missing_ids_produits = produits_df.filter(col("produit_id").isNull()).count()

print(f"Clients sans ID : {missing_ids_clients}")
print(f"Commandes sans ID : {missing_ids_commandes}")
print(f"Détails sans ID : {missing_ids_details}")
print(f"Produits sans ID : {missing_ids_produits}")

# 7/ Vérification des commandes avec clients inexistants
commandes_with_invalid_clients = commandes_df.join(
    clients_df, commandes_df["client_id"] == clients_df["client_id"], "left_anti"
).count()
print(f"Commandes avec clients inexistants : {commandes_with_invalid_clients}")

# 8/ Vérification des incohérences dans le prix total
commandes_details_sum = details_commande_df.groupBy("commande_id") \
    .agg(round(sum(col("prix_total")), 2).alias("calculated_prix_total"))

commandes_with_price_mismatch = commandes_df.join(
    commandes_details_sum, "commande_id", "left"
).filter(round(col("prix_total"), 2) != round(col("calculated_prix_total"), 2)).count()

print(f"Commandes avec incohérences de prix total : {commandes_with_price_mismatch}")

# 9/ Vérifications des détails de commande
# a) Jointure avec produits
details_commande_df = details_commande_df.join(
    produits_df, "produit_id", "left"
)
print(f"Après la jointure avec produits_df : {details_commande_df.count()}")
details_commande_df.filter(col("produit_prix_unitaire").isNull()).show(5)

# b) Vérification du prix unitaire et total
details_commande_df = details_commande_df.filter(
    round(col("prix_total"), 2) == round(col("prix_unitaire") * col("quantite"), 2)
)
print(f"Après le filtrage des incohérences de prix : {details_commande_df.count()}")

# c) Vérification des doublons de produit par commande
duplicate_products_in_commandes = details_commande_df.groupBy("commande_id", "produit_id") \
    .agg(count("*").alias("count")) \
    .filter(col("count") > 1).count()
print(f"Commandes avec produits en double : {duplicate_products_in_commandes}")

# d) Contrôle des stocks
stock_check = details_commande_df.groupBy("produit_id") \
    .agg(sum("quantite").alias("total_commande")) \
    .join(produits_df, "produit_id") \
    .filter(col("total_commande") > col("stock"))

if stock_check.count() > 0:
    print("Erreur : Certains produits ont des commandes dépassant leur stock disponible.")
    stock_check.select("produit_id", "total_commande", "stock").show()
else:
    print("Tous les stocks sont en règle.")

# 10/ Fonction pour sauvegarder avec un nom fixe

def save_with_fixed_name(dataframe, output_dir, output_file):
    tmp_dir = f"{output_dir}_tmp"
    # Écrire dans un répertoire temporaire
    dataframe.coalesce(1).write.csv(tmp_dir, header=True, mode="overwrite")
    # Trouver le fichier généré
    part_file = glob.glob(f"{tmp_dir}/part-00000*.csv")[0]
    # Renommer en utilisant le nom souhaité
    os.rename(part_file, f"{output_dir}/{output_file}")
    # Supprimer le répertoire temporaire
    shutil.rmtree(tmp_dir)  # Utilisation de shutil.rmtree pour supprimer le répertoire complet


# Sauvegarde des données nettoyées dans la zone staging avec noms fixes
save_with_fixed_name(clients_df, staging_path, "clients_cleaned.csv")
save_with_fixed_name(commandes_df, staging_path, "commandes_cleaned.csv")
save_with_fixed_name(details_commande_df, staging_path, "details_commande_cleaned.csv")
save_with_fixed_name(produits_df, staging_path, "produits_cleaned.csv")

# 11/ Résultats finaux
print(f"Commandes avec des incohérences de prix total : {commandes_with_price_mismatch}")
print(f"Détails avec commandes inexistantes : {details_commande_df.filter(col('commande_id').isNull()).count()}")
print(f"Détails avec produits inexistants : {details_commande_df.filter(col('produit_id').isNull()).count()}")

# 12/ Arrêter SparkSession
spark.stop()
