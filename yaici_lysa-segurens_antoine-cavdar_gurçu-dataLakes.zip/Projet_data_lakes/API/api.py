from fastapi import FastAPI
from fastapi.responses import JSONResponse
import pandas as pd

app = FastAPI()

# Chemin des fichiers d'analyse
analytics_path = "/home/gcavdar/Projet_data_lakes/Analytics/transactions"

# Endpoint pour chaque analyse

@app.get("/")
def read_root():
    return {"message": "Bienvenue dans l'API d'analyse de notre site !"}

@app.get("/client-performance")
def get_client_performance():
    df = pd.read_csv(f"{analytics_path}/client_performance.csv")
    return JSONResponse(content=df.to_dict(orient="records"))

@app.get("/produit-performance")
def get_produit_performance():
    df = pd.read_csv(f"{analytics_path}/produit_performance.csv")
    return JSONResponse(content=df.to_dict(orient="records"))

@app.get("/categorie-performance")
def get_categorie_performance():
    df = pd.read_csv(f"{analytics_path}/categorie_performance.csv")
    return JSONResponse(content=df.to_dict(orient="records"))

@app.get("/stats-globales")
def get_stats_globales():
    df = pd.read_csv(f"{analytics_path}/stats_globales.csv")
    return JSONResponse(content=df.to_dict(orient="records"))

@app.get("/ventes-par-pays")
def get_ventes_par_pays():
    df = pd.read_csv(f"{analytics_path}/ventes_par_pays.csv")
    return JSONResponse(content=df.to_dict(orient="records"))
