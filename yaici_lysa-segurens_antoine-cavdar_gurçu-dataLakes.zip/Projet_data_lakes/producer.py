from kafka import KafkaProducer
import json
import random
import time
from datetime import datetime

# Configuration du Producteur Kafka
producer = KafkaProducer(
    bootstrap_servers=['localhost:9092'],
    value_serializer=lambda v: json.dumps(v).encode('utf-8')  # Conversion des messages en JSON
)

# Simulation des données publicitaires
platforms = ["Facebook", "Instagram", "Google Ads"]
categories = ["Vêtements", "Chaussures", "Accessoires", "Sacs"]
user_ids = [f"user_{i}" for i in range(1, 100)]
ad_ids = [f"ad_{i}" for i in range(1, 20)]

# Fonction pour générer des événements publicitaires
def generate_ad_event():
    return {
        "ad_id": random.choice(ad_ids),
        "user_id": random.choice(user_ids),
        "click": random.choice([True, False]),
        "impression": True,
        "timestamp": datetime.utcnow().isoformat(),
        "ad_platform": random.choice(platforms),
        "product_category": random.choice(categories)
    }

# Envoyer des données en continu
try:
    while True:
        event = generate_ad_event()
        producer.send("ad_events", value=event)  # Envoi à Kafka
        print(f"Envoyé : {event}")
        time.sleep(random.uniform(0.1, 1.0))  # Pause aléatoire pour simuler un flux variable
except KeyboardInterrupt:
    print("Arrêt du producteur")
    producer.close()

