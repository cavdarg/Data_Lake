from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum, count, expr, avg
import shutil
import glob
import os

# 1/ Initialiser SparkSession
spark = SparkSession.builder \
    .appName("E-Commerce Analytics Pipeline") \
    .getOrCreate()

# 2/ Définir les chemins pour les zones staging et analytics
staging_path = r"/home/gcavdar/Projet_data_lakes/Staging/transactions"
analytics_path = r"/home/gcavdar/Projet_data_lakes/Analytics/transactions"

# 3/ Charger les fichiers nettoyés depuis la zone staging
clients_df = spark.read.option("header", "true").csv(f"{staging_path}/clients_cleaned.csv")
commandes_df = spark.read.option("header", "true").csv(f"{staging_path}/commandes_cleaned.csv")
details_commande_df = spark.read.option("header", "true").csv(f"{staging_path}/details_commande_cleaned.csv")
produits_df = spark.read.option("header", "true").csv(f"{staging_path}/produits_cleaned.csv")

# Convertir les colonnes numériques au bon type (si nécessaire)
clients_df = clients_df.withColumn("client_id", col("client_id").cast("int"))
commandes_df = commandes_df.withColumn("client_id", col("client_id").cast("int")) \
    .withColumn("commande_id", col("commande_id").cast("int")) \
    .withColumn("prix_total", col("prix_total").cast("float"))
details_commande_df = details_commande_df.withColumn("commande_id", col("commande_id").cast("int")) \
    .withColumn("produit_id", col("produit_id").cast("int")) \
    .withColumn("quantite", col("quantite").cast("int")) \
    .withColumn("prix_total", col("prix_total").cast("float")) \
    .withColumn("prix_unitaire", col("prix_unitaire").cast("float"))
produits_df = produits_df.withColumn("produit_id", col("produit_id").cast("int")) \
    .withColumn("stock", col("stock").cast("int"))

# 4/ Calculs analytiques

# a) Performance des clients
client_performance = commandes_df.groupBy("client_id") \
    .agg(
        count("commande_id").alias("nombre_commandes"),
        sum("prix_total").alias("total_depenses")
    ) \
    .orderBy(col("total_depenses").desc())

# b) Performance des produits
produit_performance = details_commande_df.groupBy("produit_id") \
    .agg(
        sum("quantite").alias("total_quantite_vendue"),
        sum("prix_total").alias("chiffre_affaires"),
        avg("prix_unitaire").alias("prix_moyen")
    ) \
    .join(produits_df.select("produit_id", "stock"), "produit_id") \
    .withColumn("taux_ecoulement", expr("total_quantite_vendue / stock"))

# c) Performance des catégories/marques
# Renommer `categorie` dans produits_df pour éviter les conflits
produits_renamed = produits_df.withColumnRenamed("categorie", "produit_categorie")

categorie_performance = details_commande_df \
    .join(produits_renamed.select("produit_id", "produit_categorie"), "produit_id") \
    .groupBy("produit_categorie") \
    .agg(
        sum("quantite").alias("quantite_totale"),
        sum("prix_total").alias("chiffre_affaires")
    ) \
    .withColumnRenamed("produit_categorie", "categorie")

# d) Statistiques globales
stats_globales = commandes_df.agg(
    sum("prix_total").alias("chiffre_affaires_total"),
    count("commande_id").alias("nombre_commandes"),
    (sum("prix_total") / count("commande_id")).alias("panier_moyen")
)

# e) Répartition géographique
ventes_par_pays = commandes_df.join(clients_df, "client_id") \
    .groupBy("pays") \
    .agg(
        sum("prix_total").alias("chiffre_affaires"),
        count("commande_id").alias("nombre_commandes")
    )

# 5/ Fonction pour sauvegarder avec des noms fixes
def save_with_fixed_name(dataframe, output_dir, output_file):
    tmp_dir = f"{output_dir}_tmp"
    # Écrire dans un répertoire temporaire
    dataframe.coalesce(1).write.csv(tmp_dir, header=True, mode="overwrite")
    # Trouver le fichier généré
    part_file = glob.glob(f"{tmp_dir}/part-00000*.csv")[0]
    # Renommer en utilisant le nom souhaité
    os.rename(part_file, f"{output_dir}/{output_file}")
    # Supprimer le répertoire temporaire
    shutil.rmtree(tmp_dir)

# 6/ Sauvegarde des résultats dans la zone Analytics
save_with_fixed_name(client_performance, analytics_path, "client_performance.csv")
save_with_fixed_name(produit_performance, analytics_path, "produit_performance.csv")
save_with_fixed_name(categorie_performance, analytics_path, "categorie_performance.csv")
save_with_fixed_name(stats_globales, analytics_path, "stats_globales.csv")
save_with_fixed_name(ventes_par_pays, analytics_path, "ventes_par_pays.csv")

# 7/ Arrêter SparkSession
spark.stop()
